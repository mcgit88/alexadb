import sys
import logging
import psycopg2

from db_util import make_conn, fetch_data
def lambda_handler(event, context):
    fieldval= event['City']
    query_cmd = "INSERT INTO FieldDetails (FieldValue) VALUES ('$[fieldval]');"
    print query_cmd

    # get a connection, if a connect cannot be made an exception will be raised here
    conn = make_conn()

    result = fetch_data(conn, query_cmd)
    conn.close()

    return result